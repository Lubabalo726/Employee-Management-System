﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Details))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DobLbl = New System.Windows.Forms.Label()
        Me.EmpEducaLbl = New System.Windows.Forms.Label()
        Me.EmpPosLbl = New System.Windows.Forms.Label()
        Me.EmpAddLbl = New System.Windows.Forms.Label()
        Me.EmpPhonelbl = New System.Windows.Forms.Label()
        Me.EmpGenderlbl = New System.Windows.Forms.Label()
        Me.EmpNamelbl = New System.Windows.Forms.Label()
        Me.BtnFetchData = New System.Windows.Forms.Button()
        Me.EmpidTb = New System.Windows.Forms.TextBox()
        Me.LblEmployeeId = New System.Windows.Forms.Label()
        Me.BtnHome = New System.Windows.Forms.Button()
        Me.EmpEduca = New System.Windows.Forms.Label()
        Me.Dob = New System.Windows.Forms.Label()
        Me.EmpPos = New System.Windows.Forms.Label()
        Me.EmpAdd = New System.Windows.Forms.Label()
        Me.Phne = New System.Windows.Forms.Label()
        Me.EmpGend = New System.Windows.Forms.Label()
        Me.EmployNam = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(105, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 13)
        Me.Label1.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.Controls.Add(Me.DobLbl)
        Me.Panel1.Controls.Add(Me.EmpEducaLbl)
        Me.Panel1.Controls.Add(Me.EmpPosLbl)
        Me.Panel1.Controls.Add(Me.EmpAddLbl)
        Me.Panel1.Controls.Add(Me.EmpPhonelbl)
        Me.Panel1.Controls.Add(Me.EmpGenderlbl)
        Me.Panel1.Controls.Add(Me.EmpNamelbl)
        Me.Panel1.Controls.Add(Me.BtnFetchData)
        Me.Panel1.Controls.Add(Me.EmpidTb)
        Me.Panel1.Controls.Add(Me.LblEmployeeId)
        Me.Panel1.Controls.Add(Me.BtnHome)
        Me.Panel1.Controls.Add(Me.EmpEduca)
        Me.Panel1.Controls.Add(Me.Dob)
        Me.Panel1.Controls.Add(Me.EmpPos)
        Me.Panel1.Controls.Add(Me.EmpAdd)
        Me.Panel1.Controls.Add(Me.Phne)
        Me.Panel1.Controls.Add(Me.EmpGend)
        Me.Panel1.Controls.Add(Me.EmployNam)
        Me.Panel1.Location = New System.Drawing.Point(-13, 50)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(606, 334)
        Me.Panel1.TabIndex = 3
        '
        'DobLbl
        '
        Me.DobLbl.AutoSize = True
        Me.DobLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DobLbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.DobLbl.Location = New System.Drawing.Point(337, 283)
        Me.DobLbl.Name = "DobLbl"
        Me.DobLbl.Size = New System.Drawing.Size(0, 13)
        Me.DobLbl.TabIndex = 48
        Me.DobLbl.Visible = False
        '
        'EmpEducaLbl
        '
        Me.EmpEducaLbl.AutoSize = True
        Me.EmpEducaLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpEducaLbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.EmpEducaLbl.Location = New System.Drawing.Point(461, 225)
        Me.EmpEducaLbl.Name = "EmpEducaLbl"
        Me.EmpEducaLbl.Size = New System.Drawing.Size(0, 13)
        Me.EmpEducaLbl.TabIndex = 47
        Me.EmpEducaLbl.Visible = False
        '
        'EmpPosLbl
        '
        Me.EmpPosLbl.AutoSize = True
        Me.EmpPosLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpPosLbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.EmpPosLbl.Location = New System.Drawing.Point(449, 168)
        Me.EmpPosLbl.Name = "EmpPosLbl"
        Me.EmpPosLbl.Size = New System.Drawing.Size(0, 13)
        Me.EmpPosLbl.TabIndex = 46
        Me.EmpPosLbl.Visible = False
        '
        'EmpAddLbl
        '
        Me.EmpAddLbl.AutoSize = True
        Me.EmpAddLbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpAddLbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.EmpAddLbl.Location = New System.Drawing.Point(436, 109)
        Me.EmpAddLbl.Name = "EmpAddLbl"
        Me.EmpAddLbl.Size = New System.Drawing.Size(0, 13)
        Me.EmpAddLbl.TabIndex = 45
        Me.EmpAddLbl.Visible = False
        '
        'EmpPhonelbl
        '
        Me.EmpPhonelbl.AutoSize = True
        Me.EmpPhonelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpPhonelbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.EmpPhonelbl.Location = New System.Drawing.Point(225, 222)
        Me.EmpPhonelbl.Name = "EmpPhonelbl"
        Me.EmpPhonelbl.Size = New System.Drawing.Size(0, 13)
        Me.EmpPhonelbl.TabIndex = 44
        Me.EmpPhonelbl.Visible = False
        '
        'EmpGenderlbl
        '
        Me.EmpGenderlbl.AutoSize = True
        Me.EmpGenderlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpGenderlbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.EmpGenderlbl.Location = New System.Drawing.Point(225, 167)
        Me.EmpGenderlbl.Name = "EmpGenderlbl"
        Me.EmpGenderlbl.Size = New System.Drawing.Size(0, 13)
        Me.EmpGenderlbl.TabIndex = 43
        Me.EmpGenderlbl.Visible = False
        '
        'EmpNamelbl
        '
        Me.EmpNamelbl.AutoSize = True
        Me.EmpNamelbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpNamelbl.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.EmpNamelbl.Location = New System.Drawing.Point(224, 106)
        Me.EmpNamelbl.Name = "EmpNamelbl"
        Me.EmpNamelbl.Size = New System.Drawing.Size(0, 13)
        Me.EmpNamelbl.TabIndex = 32
        Me.EmpNamelbl.Visible = False
        '
        'BtnFetchData
        '
        Me.BtnFetchData.FlatAppearance.BorderSize = 0
        Me.BtnFetchData.ForeColor = System.Drawing.Color.Black
        Me.BtnFetchData.Location = New System.Drawing.Point(363, 46)
        Me.BtnFetchData.Name = "BtnFetchData"
        Me.BtnFetchData.Size = New System.Drawing.Size(92, 26)
        Me.BtnFetchData.TabIndex = 42
        Me.BtnFetchData.Text = "Fetch"
        Me.BtnFetchData.UseVisualStyleBackColor = True
        '
        'EmpidTb
        '
        Me.EmpidTb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.EmpidTb.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpidTb.Location = New System.Drawing.Point(200, 46)
        Me.EmpidTb.Multiline = True
        Me.EmpidTb.Name = "EmpidTb"
        Me.EmpidTb.Size = New System.Drawing.Size(157, 20)
        Me.EmpidTb.TabIndex = 41
        Me.EmpidTb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'LblEmployeeId
        '
        Me.LblEmployeeId.AutoSize = True
        Me.LblEmployeeId.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblEmployeeId.Location = New System.Drawing.Point(116, 46)
        Me.LblEmployeeId.Name = "LblEmployeeId"
        Me.LblEmployeeId.Size = New System.Drawing.Size(78, 15)
        Me.LblEmployeeId.TabIndex = 40
        Me.LblEmployeeId.Text = "Employee id:"
        '
        'BtnHome
        '
        Me.BtnHome.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnHome.FlatAppearance.BorderSize = 0
        Me.BtnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHome.Location = New System.Drawing.Point(48, 283)
        Me.BtnHome.Name = "BtnHome"
        Me.BtnHome.Size = New System.Drawing.Size(59, 32)
        Me.BtnHome.TabIndex = 39
        Me.BtnHome.Text = "Home"
        Me.BtnHome.UseVisualStyleBackColor = False
        '
        'EmpEduca
        '
        Me.EmpEduca.AutoSize = True
        Me.EmpEduca.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpEduca.ForeColor = System.Drawing.Color.White
        Me.EmpEduca.Location = New System.Drawing.Point(343, 223)
        Me.EmpEduca.Name = "EmpEduca"
        Me.EmpEduca.Size = New System.Drawing.Size(123, 15)
        Me.EmpEduca.TabIndex = 37
        Me.EmpEduca.Text = "Employee Education:"
        '
        'Dob
        '
        Me.Dob.AutoSize = True
        Me.Dob.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dob.Location = New System.Drawing.Point(253, 281)
        Me.Dob.Name = "Dob"
        Me.Dob.Size = New System.Drawing.Size(77, 15)
        Me.Dob.TabIndex = 36
        Me.Dob.Text = "Date of Birth:"
        '
        'EmpPos
        '
        Me.EmpPos.AutoSize = True
        Me.EmpPos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpPos.ForeColor = System.Drawing.Color.White
        Me.EmpPos.Location = New System.Drawing.Point(343, 165)
        Me.EmpPos.Name = "EmpPos"
        Me.EmpPos.Size = New System.Drawing.Size(112, 15)
        Me.EmpPos.TabIndex = 35
        Me.EmpPos.Text = "Employee Position:"
        '
        'EmpAdd
        '
        Me.EmpAdd.AutoSize = True
        Me.EmpAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpAdd.ForeColor = System.Drawing.Color.White
        Me.EmpAdd.Location = New System.Drawing.Point(343, 109)
        Me.EmpAdd.Name = "EmpAdd"
        Me.EmpAdd.Size = New System.Drawing.Size(112, 15)
        Me.EmpAdd.TabIndex = 34
        Me.EmpAdd.Text = "Employee Address:"
        '
        'Phne
        '
        Me.Phne.AutoSize = True
        Me.Phne.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Phne.ForeColor = System.Drawing.Color.White
        Me.Phne.Location = New System.Drawing.Point(116, 222)
        Me.Phne.Name = "Phne"
        Me.Phne.Size = New System.Drawing.Size(104, 15)
        Me.Phne.TabIndex = 33
        Me.Phne.Text = "Employee Phone:"
        '
        'EmpGend
        '
        Me.EmpGend.AutoSize = True
        Me.EmpGend.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpGend.ForeColor = System.Drawing.Color.White
        Me.EmpGend.Location = New System.Drawing.Point(116, 165)
        Me.EmpGend.Name = "EmpGend"
        Me.EmpGend.Size = New System.Drawing.Size(109, 15)
        Me.EmpGend.TabIndex = 32
        Me.EmpGend.Text = "Employee Gender:"
        '
        'EmployNam
        '
        Me.EmployNam.AutoSize = True
        Me.EmployNam.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployNam.ForeColor = System.Drawing.Color.White
        Me.EmployNam.Location = New System.Drawing.Point(116, 104)
        Me.EmployNam.Name = "EmployNam"
        Me.EmployNam.Size = New System.Drawing.Size(102, 15)
        Me.EmployNam.TabIndex = 31
        Me.EmployNam.Text = "Employee Name:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(5, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(47, 35)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 49
        Me.PictureBox1.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(57, 31)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 16)
        Me.Label5.TabIndex = 50
        Me.Label5.Text = "HOME"
        '
        'Details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(589, 422)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.Color.White
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Details"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Details"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents EmpidTb As System.Windows.Forms.TextBox
    Friend WithEvents LblEmployeeId As System.Windows.Forms.Label
    Friend WithEvents BtnHome As System.Windows.Forms.Button
    Friend WithEvents EmpEduca As System.Windows.Forms.Label
    Friend WithEvents Dob As System.Windows.Forms.Label
    Friend WithEvents EmpPos As System.Windows.Forms.Label
    Friend WithEvents EmpAdd As System.Windows.Forms.Label
    Friend WithEvents Phne As System.Windows.Forms.Label
    Friend WithEvents EmpGend As System.Windows.Forms.Label
    Friend WithEvents EmployNam As System.Windows.Forms.Label
    Friend WithEvents BtnFetchData As System.Windows.Forms.Button
    Friend WithEvents EmpAddLbl As System.Windows.Forms.Label
    Friend WithEvents EmpPhonelbl As System.Windows.Forms.Label
    Friend WithEvents EmpGenderlbl As System.Windows.Forms.Label
    Friend WithEvents EmpNamelbl As System.Windows.Forms.Label
    Friend WithEvents EmpPosLbl As System.Windows.Forms.Label
    Friend WithEvents EmpEducaLbl As System.Windows.Forms.Label
    Friend WithEvents DobLbl As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label5 As Label
End Class
