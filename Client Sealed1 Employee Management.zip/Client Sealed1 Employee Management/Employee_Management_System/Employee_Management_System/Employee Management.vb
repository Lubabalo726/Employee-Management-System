﻿Public Class Employee_Management
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

        Me.Hide()
        Dim Emp = New Employee
        Emp.Show()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

        Me.Hide()
        Dim Emp = New Employee
        Emp.Show()

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

        Me.Hide()
        Dim Detail = New Details
        Details.Show()

    End Sub
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

        Me.Hide()
        Dim Detail = New Details
        Details.Show()

    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click

        Me.Hide()
        Dim Salary = New Salary
        Salary.Show()

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

        Me.Hide()
        Dim Salary = New Salary
        Salary.Show()

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

        Me.Hide()
        Dim employee = New Employee
        employee.Show()

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs)

        Me.Hide()
        Dim employee = New Employee
        employee.Show()

    End Sub
End Class