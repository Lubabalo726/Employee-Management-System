﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Employee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PosCb = New System.Windows.Forms.ComboBox()
        Me.EmpPos = New System.Windows.Forms.Label()
        Me.BtnClose = New System.Windows.Forms.Button()
        Me.EmpGendCb = New System.Windows.Forms.ComboBox()
        Me.EmpGend = New System.Windows.Forms.Label()
        Me.EmpEdCb = New System.Windows.Forms.ComboBox()
        Me.EmpEducation = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.BtnHome = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.BtnDelete = New System.Windows.Forms.Button()
        Me.BtnEdit = New System.Windows.Forms.Button()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.EmpDob = New System.Windows.Forms.DateTimePicker()
        Me.DateOFBirth = New System.Windows.Forms.Label()
        Me.EmpAddTb = New System.Windows.Forms.TextBox()
        Me.EmpAdd = New System.Windows.Forms.Label()
        Me.EmpPhne = New System.Windows.Forms.Label()
        Me.EmpPhoneTb = New System.Windows.Forms.TextBox()
        Me.EmpNamTb = New System.Windows.Forms.TextBox()
        Me.EmployNam = New System.Windows.Forms.Label()
        Me.Exitlbl = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Teal
        Me.Panel1.Controls.Add(Me.PosCb)
        Me.Panel1.Controls.Add(Me.EmpPos)
        Me.Panel1.Controls.Add(Me.BtnClose)
        Me.Panel1.Controls.Add(Me.EmpGendCb)
        Me.Panel1.Controls.Add(Me.EmpGend)
        Me.Panel1.Controls.Add(Me.EmpEdCb)
        Me.Panel1.Controls.Add(Me.EmpEducation)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.BtnHome)
        Me.Panel1.Controls.Add(Me.BtnReset)
        Me.Panel1.Controls.Add(Me.BtnDelete)
        Me.Panel1.Controls.Add(Me.BtnEdit)
        Me.Panel1.Controls.Add(Me.BtnAdd)
        Me.Panel1.Controls.Add(Me.EmpDob)
        Me.Panel1.Controls.Add(Me.DateOFBirth)
        Me.Panel1.Controls.Add(Me.EmpAddTb)
        Me.Panel1.Controls.Add(Me.EmpAdd)
        Me.Panel1.Controls.Add(Me.EmpPhne)
        Me.Panel1.Controls.Add(Me.EmpPhoneTb)
        Me.Panel1.Controls.Add(Me.EmpNamTb)
        Me.Panel1.Controls.Add(Me.EmployNam)
        Me.Panel1.Location = New System.Drawing.Point(-5, 66)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(907, 382)
        Me.Panel1.TabIndex = 0
        '
        'PosCb
        '
        Me.PosCb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.PosCb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PosCb.FormattingEnabled = True
        Me.PosCb.Items.AddRange(New Object() {"Manager", "Administrator", "Accountant", "IT", "Cleaner", "Security"})
        Me.PosCb.Location = New System.Drawing.Point(176, 150)
        Me.PosCb.Name = "PosCb"
        Me.PosCb.Size = New System.Drawing.Size(100, 24)
        Me.PosCb.TabIndex = 22
        '
        'EmpPos
        '
        Me.EmpPos.AutoSize = True
        Me.EmpPos.ForeColor = System.Drawing.Color.White
        Me.EmpPos.Location = New System.Drawing.Point(180, 116)
        Me.EmpPos.Name = "EmpPos"
        Me.EmpPos.Size = New System.Drawing.Size(96, 13)
        Me.EmpPos.TabIndex = 21
        Me.EmpPos.Text = "Employee Position:"
        '
        'BtnClose
        '
        Me.BtnClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnClose.FlatAppearance.BorderSize = 0
        Me.BtnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnClose.Location = New System.Drawing.Point(284, 297)
        Me.BtnClose.Name = "BtnClose"
        Me.BtnClose.Size = New System.Drawing.Size(75, 32)
        Me.BtnClose.TabIndex = 20
        Me.BtnClose.Text = "Close"
        Me.BtnClose.UseVisualStyleBackColor = False
        '
        'EmpGendCb
        '
        Me.EmpGendCb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpGendCb.FormattingEnabled = True
        Me.EmpGendCb.Items.AddRange(New Object() {"Male", "Female"})
        Me.EmpGendCb.Location = New System.Drawing.Point(42, 150)
        Me.EmpGendCb.Name = "EmpGendCb"
        Me.EmpGendCb.Size = New System.Drawing.Size(100, 24)
        Me.EmpGendCb.TabIndex = 3
        '
        'EmpGend
        '
        Me.EmpGend.AutoSize = True
        Me.EmpGend.ForeColor = System.Drawing.Color.White
        Me.EmpGend.Location = New System.Drawing.Point(48, 116)
        Me.EmpGend.Name = "EmpGend"
        Me.EmpGend.Size = New System.Drawing.Size(94, 13)
        Me.EmpGend.TabIndex = 2
        Me.EmpGend.Text = "Employee Gender:"
        '
        'EmpEdCb
        '
        Me.EmpEdCb.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EmpEdCb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpEdCb.FormattingEnabled = True
        Me.EmpEdCb.Items.AddRange(New Object() {"Matric", "Certification", "Diploma", "Degree", "Honors", "None"})
        Me.EmpEdCb.Location = New System.Drawing.Point(171, 229)
        Me.EmpEdCb.Name = "EmpEdCb"
        Me.EmpEdCb.Size = New System.Drawing.Size(104, 24)
        Me.EmpEdCb.TabIndex = 19
        '
        'EmpEducation
        '
        Me.EmpEducation.AutoSize = True
        Me.EmpEducation.ForeColor = System.Drawing.Color.White
        Me.EmpEducation.Location = New System.Drawing.Point(171, 200)
        Me.EmpEducation.Name = "EmpEducation"
        Me.EmpEducation.Size = New System.Drawing.Size(107, 13)
        Me.EmpEducation.TabIndex = 18
        Me.EmpEducation.Text = "Employee Education:"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToResizeColumns = False
        Me.DataGridView1.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.DataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        Me.DataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.Olive
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView1.ColumnHeadersHeight = 40
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.GridColor = System.Drawing.Color.White
        Me.DataGridView1.Location = New System.Drawing.Point(392, 13)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.White
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(494, 344)
        Me.DataGridView1.TabIndex = 17
        '
        'BtnHome
        '
        Me.BtnHome.BackColor = System.Drawing.Color.Olive
        Me.BtnHome.FlatAppearance.BorderSize = 0
        Me.BtnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnHome.Location = New System.Drawing.Point(284, 250)
        Me.BtnHome.Name = "BtnHome"
        Me.BtnHome.Size = New System.Drawing.Size(75, 32)
        Me.BtnHome.TabIndex = 16
        Me.BtnHome.Text = "Home"
        Me.BtnHome.UseVisualStyleBackColor = False
        '
        'BtnReset
        '
        Me.BtnReset.BackColor = System.Drawing.Color.Yellow
        Me.BtnReset.FlatAppearance.BorderSize = 0
        Me.BtnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnReset.Location = New System.Drawing.Point(284, 200)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(75, 32)
        Me.BtnReset.TabIndex = 15
        Me.BtnReset.Text = "Reset"
        Me.BtnReset.UseVisualStyleBackColor = False
        '
        'BtnDelete
        '
        Me.BtnDelete.BackColor = System.Drawing.Color.Red
        Me.BtnDelete.FlatAppearance.BorderSize = 0
        Me.BtnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnDelete.Location = New System.Drawing.Point(284, 98)
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.Size = New System.Drawing.Size(75, 32)
        Me.BtnDelete.TabIndex = 14
        Me.BtnDelete.Text = "Delete"
        Me.BtnDelete.UseVisualStyleBackColor = False
        '
        'BtnEdit
        '
        Me.BtnEdit.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnEdit.FlatAppearance.BorderSize = 0
        Me.BtnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnEdit.Location = New System.Drawing.Point(284, 151)
        Me.BtnEdit.Name = "BtnEdit"
        Me.BtnEdit.Size = New System.Drawing.Size(75, 32)
        Me.BtnEdit.TabIndex = 13
        Me.BtnEdit.Text = "Update"
        Me.BtnEdit.UseVisualStyleBackColor = False
        '
        'BtnAdd
        '
        Me.BtnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BtnAdd.FlatAppearance.BorderSize = 0
        Me.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnAdd.Location = New System.Drawing.Point(284, 47)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(75, 32)
        Me.BtnAdd.TabIndex = 12
        Me.BtnAdd.Text = "Add"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'EmpDob
        '
        Me.EmpDob.CustomFormat = "dd/mm/yyyy"
        Me.EmpDob.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpDob.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.EmpDob.Location = New System.Drawing.Point(111, 305)
        Me.EmpDob.Name = "EmpDob"
        Me.EmpDob.Size = New System.Drawing.Size(100, 25)
        Me.EmpDob.TabIndex = 11
        Me.EmpDob.Value = New Date(2021, 10, 14, 0, 0, 0, 0)
        '
        'DateOFBirth
        '
        Me.DateOFBirth.AutoSize = True
        Me.DateOFBirth.ForeColor = System.Drawing.Color.White
        Me.DateOFBirth.Location = New System.Drawing.Point(124, 277)
        Me.DateOFBirth.Name = "DateOFBirth"
        Me.DateOFBirth.Size = New System.Drawing.Size(69, 13)
        Me.DateOFBirth.TabIndex = 10
        Me.DateOFBirth.Text = "Date of Birth:"
        '
        'EmpAddTb
        '
        Me.EmpAddTb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.EmpAddTb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpAddTb.Location = New System.Drawing.Point(175, 47)
        Me.EmpAddTb.Multiline = True
        Me.EmpAddTb.Name = "EmpAddTb"
        Me.EmpAddTb.Size = New System.Drawing.Size(100, 50)
        Me.EmpAddTb.TabIndex = 7
        '
        'EmpAdd
        '
        Me.EmpAdd.AutoSize = True
        Me.EmpAdd.ForeColor = System.Drawing.Color.White
        Me.EmpAdd.Location = New System.Drawing.Point(178, 31)
        Me.EmpAdd.Name = "EmpAdd"
        Me.EmpAdd.Size = New System.Drawing.Size(97, 13)
        Me.EmpAdd.TabIndex = 6
        Me.EmpAdd.Text = "Employee Address:"
        '
        'EmpPhne
        '
        Me.EmpPhne.AutoSize = True
        Me.EmpPhne.ForeColor = System.Drawing.Color.White
        Me.EmpPhne.Location = New System.Drawing.Point(48, 200)
        Me.EmpPhne.Name = "EmpPhne"
        Me.EmpPhne.Size = New System.Drawing.Size(90, 13)
        Me.EmpPhne.TabIndex = 5
        Me.EmpPhne.Text = "Employee Phone:"
        '
        'EmpPhoneTb
        '
        Me.EmpPhoneTb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.EmpPhoneTb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpPhoneTb.Location = New System.Drawing.Point(42, 231)
        Me.EmpPhoneTb.Multiline = True
        Me.EmpPhoneTb.Name = "EmpPhoneTb"
        Me.EmpPhoneTb.Size = New System.Drawing.Size(100, 20)
        Me.EmpPhoneTb.TabIndex = 4
        '
        'EmpNamTb
        '
        Me.EmpNamTb.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.EmpNamTb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmpNamTb.Location = New System.Drawing.Point(42, 77)
        Me.EmpNamTb.Multiline = True
        Me.EmpNamTb.Name = "EmpNamTb"
        Me.EmpNamTb.Size = New System.Drawing.Size(100, 20)
        Me.EmpNamTb.TabIndex = 1
        '
        'EmployNam
        '
        Me.EmployNam.AutoSize = True
        Me.EmployNam.ForeColor = System.Drawing.Color.White
        Me.EmployNam.Location = New System.Drawing.Point(52, 45)
        Me.EmployNam.Name = "EmployNam"
        Me.EmployNam.Size = New System.Drawing.Size(87, 13)
        Me.EmployNam.TabIndex = 0
        Me.EmployNam.Text = "Employee Name:"
        '
        'Exitlbl
        '
        Me.Exitlbl.AutoSize = True
        Me.Exitlbl.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Exitlbl.ForeColor = System.Drawing.Color.Red
        Me.Exitlbl.Location = New System.Drawing.Point(857, 18)
        Me.Exitlbl.Name = "Exitlbl"
        Me.Exitlbl.Size = New System.Drawing.Size(18, 18)
        Me.Exitlbl.TabIndex = 23
        Me.Exitlbl.Text = "X"
        '
        'Employee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(896, 491)
        Me.Controls.Add(Me.Exitlbl)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Employee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Employee"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents EmpAdd As System.Windows.Forms.Label
    Friend WithEvents EmpPhne As System.Windows.Forms.Label
    Friend WithEvents EmpPhoneTb As System.Windows.Forms.TextBox
    Friend WithEvents EmpGendCb As System.Windows.Forms.ComboBox
    Friend WithEvents EmpGend As System.Windows.Forms.Label
    Friend WithEvents EmpNamTb As System.Windows.Forms.TextBox
    Friend WithEvents EmployNam As System.Windows.Forms.Label
    Friend WithEvents DateOFBirth As System.Windows.Forms.Label
    Friend WithEvents EmpAddTb As System.Windows.Forms.TextBox
    Friend WithEvents EmpDob As System.Windows.Forms.DateTimePicker
    Friend WithEvents BtnHome As System.Windows.Forms.Button
    Friend WithEvents BtnReset As System.Windows.Forms.Button
    Friend WithEvents BtnDelete As System.Windows.Forms.Button
    Friend WithEvents BtnEdit As System.Windows.Forms.Button
    Friend WithEvents BtnAdd As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents EmpEdCb As System.Windows.Forms.ComboBox
    Friend WithEvents EmpEducation As System.Windows.Forms.Label
    Friend WithEvents BtnClose As System.Windows.Forms.Button
    Friend WithEvents PosCb As System.Windows.Forms.ComboBox
    Friend WithEvents EmpPos As System.Windows.Forms.Label
    Friend WithEvents Exitlbl As System.Windows.Forms.Label
End Class
