﻿Imports System.Data.SqlClient
Public Class Salary
    Dim Connect As New SqlConnection("Data Source = eminent\sqlelihle;Initial Catalog=Employee_Table;Integrated Security=True")

    Private Sub FetchData()
        If EmpIdTb.Text = "" Then

            lblEmpName.Text = ""
            LblEmpPos.Text = ""

            MessageBox.Show("Please Enter Employee Id", "Id error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            Connect.Open()
            Dim query = "Select * From Table_Employee where Empid=" & EmpIdTb.Text & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, Connect)
            Dim Dt As DataTable
            Dt = New DataTable
            Dim SDt As SqlDataAdapter
            SDt = New SqlDataAdapter(cmd)
            SDt.Fill(Dt)

            For Each dr As DataRow In Dt.Rows
                lblEmpName.Text = dr(1).ToString()
                LblEmpPos.Text = dr(3).ToString()

                'Display Visibility of Data

                lblEmpName.Visible = True
                LblEmpPos.Visible = True

            Next

            Connect.Close()

        End If

    End Sub
    Private Sub BtnHome_Click(sender As Object, e As EventArgs) Handles BtnHome.Click

        Me.Hide()
        Dim Employee_M = New Employee_Management
        Employee_Management.Show()

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

        Application.Exit()

    End Sub

    Private Sub BtnFetchData_Click(sender As Object, e As EventArgs) Handles BtnFetchData.Click
        FetchData()
    End Sub

    Private Sub Salary_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Dim DailyPayment
    Private Sub BtnView_Click(sender As Object, e As EventArgs) Handles BtnView.Click

        Try

            If LblEmpPos.Text = "" Then

                MessageBox.Show("Select An Employee", "Employee", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ElseIf EmpWorkTb.Text = "" Or Convert.ToInt32(EmpWorkTb.Text) > 31 Then
                MessageBox.Show("Enter A Valid Numnber Of Days", "Id Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                If LblEmpPos.Text = "Manager" Then
                    DailyPayment = 1200
                ElseIf LblEmpPos.Text = "Administrator" Then
                    DailyPayment = 600
                ElseIf LblEmpPos.Text = "Accountant" Then
                    DailyPayment = 550
                ElseIf LblEmpPos.Text = "IT" Then
                    DailyPayment = 400
                ElseIf LblEmpPos.Text = "Security" Then
                    DailyPayment = 200
                ElseIf LblEmpPos.Text = "Cleaner" Then
                    DailyPayment = 170
                Else
                    DailyPayment = 100
                End If
                Dim Total = DailyPayment * Convert.ToInt32(EmpWorkTb.Text)
                RichTextBox1.Text = "Employee ID:   " + EmpIdTb.Text + vbCrLf + "Employee Name:   " + lblEmpName.Text + vbCrLf + "Employee Position:    " + LblEmpPos.Text + vbCrLf + "Days Worked:     " + EmpWorkTb.Text + vbCrLf + "Daily Salary R:    " + Convert.ToString(DailyPayment) + vbCrLf + "Total Amount R:    " + Convert.ToString(Total)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage


        Try

            e.Graphics.DrawString("Employee Management System", New Font("Century Gothic", 25), Brushes.DarkGreen, 180, 40)
            e.Graphics.DrawString("******PaySlip*******", New Font("Arial", 20), Brushes.Crimson, 330, 100)
            e.Graphics.DrawString(RichTextBox1.Text, New Font("Century Gothic", 20), Brushes.Black, 150, 190)

            e.Graphics.DrawString("*******Thanks For Your Services***********", New Font("Century Gothic", 15), Brushes.DarkGreen, 150, 500)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
       
    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs) Handles BtnPrint.Click

        PrintPreviewDialog1.Show()

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

        PrintPreviewDialog1.Show()

    End Sub
End Class