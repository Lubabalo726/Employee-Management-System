﻿Imports System.Data.SqlClient
Public Class Employee
    Dim Connect As New SqlConnection("Data Source=eminent\sqlelihle;Initial Catalog=Employee_Table;Integrated Security=True")

    Private Sub Employee_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'I am calling that method/Function in the form_Load

        Populate()

    End Sub
    ' I Just decalared a Function.
    'This is a method/Function it will allow me to add Database to the DataGridView1:
    Private Sub Populate()

        Connect.Open()
        Dim sql = "select * from Table_Employee"
        Dim adapter As SqlDataAdapter
        adapter = New SqlDataAdapter(sql, Connect)
        Dim builder As SqlCommandBuilder
        builder = New SqlCommandBuilder(adapter)
        Dim Ds As DataSet
        Ds = New DataSet
        adapter.Fill(Ds)
        DataGridView1.DataSource = Ds.Tables(0)
        Connect.Close()

    End Sub

    Private Sub BtnAdd_Click(sender As Object, e As EventArgs) Handles BtnAdd.Click

        If EmpNamTb.Text = "" Or EmpPhoneTb.Text = "" Or EmpAddTb.Text = "" Then
            MessageBox.Show("Please Fill in the Missing Information", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else

        Try

            'This connection is for the insert button
            Connect.Open()
            Dim query As String
            query = "insert into Table_Employee values('" & EmpNamTb.Text & "','" & EmpAddTb.Text & "', '" & PosCb.SelectedItem.ToString() & "', '" & EmpDob.Value & "', '" & EmpPhoneTb.Text & "','" & EmpEdCb.SelectedItem.ToString() & "', '" & EmpGendCb.SelectedItem.ToString() & "')"
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, Connect)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Employee Added Succesfully", "Add Employee", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Connect.Close()
            Populate()

        Catch ex As Exception
            MsgBox("No Nulls are allowed", MsgBoxStyle.Critical)
        End Try

        End If

    End Sub

    Private Sub BtnBack_Click(sender As Object, e As EventArgs) Handles BtnClose.Click

        Close()

    End Sub
    Dim delete = 0

    'This is another Method to clear Employees after They are deleted
    'Clears them from the Data Textboxes
    Private Sub Clear()

        EmpNamTb.Clear()
        PosCb.Text = ""
        EmpGendCb.Text = ""
        EmpAddTb.Text = ""
        delete = 0
        EmpEdCb.Text = ""
        EmpPhoneTb.Text = ""
        EmpDob.Text = ""

    End Sub


    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles BtnDelete.Click

        If delete = 0 Then
            MessageBox.Show("Select the Record you want to delete", "Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            Try

                Connect.Open()
                Dim query As String
                query = "Delete From Table_Employee Where Empid =" & delete & ""
                Dim cmd As SqlCommand
                cmd = New SqlCommand(query, Connect)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Emplyee Deleted SuccessFully", "Delete Employee", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Connect.Close()
                Populate()
                Clear()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub BtnEdit_Click(sender As Object, e As EventArgs) Handles BtnEdit.Click

        If EmpNamTb.Text = "" Or EmpPhoneTb.Text = "" Or EmpAddTb.Text = "" Then
            MessageBox.Show("Please Fill in the Missing Information", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            Try

                Connect.Open()
                Dim query As String
                query = "Update Table_Employee set Name= '" & EmpNamTb.Text & "', Address='" & EmpAddTb.Text & "',Position='" & PosCb.SelectedItem.ToString() & "',Birth='" & EmpDob.Value & "',Phone='" & EmpPhoneTb.Text & "',Education='" & EmpEdCb.SelectedItem.ToString() & "',Gender='" & EmpGendCb.SelectedItem.ToString() & "' Where Empid=" & delete & ""
                Dim cmd As New SqlCommand(query, Connect)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Employee Updated SuccessFully", "Update Employee", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Connect.Close()
                Populate()
                Clear()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

        'Clear the Data Boxes Again
        EmpNamTb.Text = ""
        EmpAddTb.Text = ""
        PosCb.Text = ""
        EmpPhoneTb.Text = ""
        EmpGendCb.Text = ""
        EmpEdCb.Text = ""

    End Sub

    Private Sub DataGridView1_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick

        Try
            'Here for the Combobox you can Say .selectedItem or . Text
            'Displaying Employee Details on the Texboxes

            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            delete = Convert.ToInt32(row.Cells(0).Value.ToString())
            EmpNamTb.Text = row.Cells(1).Value.ToString()
            EmpAddTb.Text = row.Cells(2).Value.ToString()
            PosCb.SelectedItem = row.Cells(3).Value.ToString()
            EmpDob.Value = row.Cells(4).Value.ToString()
            EmpPhoneTb.Text = row.Cells(5).Value.ToString()
            EmpEdCb.SelectedItem = row.Cells(6).Value.ToString()
            EmpGendCb.SelectedItem = row.Cells(7).Value.ToString()

        Catch ex As Exception
            MessageBox.Show("Out of Range: Parameter Index", "Index Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub
    Private Sub BtnHome_Click(sender As Object, e As EventArgs) Handles BtnHome.Click

        Me.Hide()
        Dim Employee_M = New Employee_Management
        Employee_Management.Show()

    End Sub


    Private Sub Exitlbl_Click(sender As Object, e As EventArgs) Handles Exitlbl.Click

        Application.Exit()

    End Sub

End Class