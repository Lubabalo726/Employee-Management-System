﻿Imports System.Data.SqlClient
Public Class Details
    Dim Connect As New SqlConnection("Data Source=eminent\sqlelihle;Initial Catalog=Employee_Table;Integrated Security=True")

    'This is a Method to feth Data From the employee Table, Create Private sub

    Private Sub FetchData()

        If EmpidTb.Text = "" Then

            EmpNamelbl.Text = ""
            EmpAddLbl.Text = ""
            EmpPosLbl.Text = ""
            EmpPhonelbl.Text = ""
            EmpEducaLbl.Text = ""
            EmpGenderlbl.Text = ""
            DobLbl.Text = ""

            MessageBox.Show("Please Enter Employee Id", "Id error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            Connect.Open()
            Dim query = "Select * From Table_Employee where Empid=" & EmpidTb.Text & ""
            Dim cmd As SqlCommand
            cmd = New SqlCommand(query, Connect)
            Dim Dt As DataTable
            Dt = New DataTable
            Dim SDt As SqlDataAdapter
            SDt = New SqlDataAdapter(cmd)
            SDt.Fill(Dt)

            For Each dr As DataRow In Dt.Rows
                EmpNamelbl.Text = dr(1).ToString()
                EmpAddLbl.Text = dr(2).ToString()
                EmpPosLbl.Text = dr(3).ToString()
                DobLbl.Text = dr(4).ToString()
                EmpPhonelbl.Text = dr(5).ToString()
                EmpEducaLbl.Text = dr(6).ToString()
                EmpGenderlbl.Text = dr(7).ToString()

                'Display Visibility of Data

                EmpNamelbl.Visible = True
                EmpAddLbl.Visible = True
                EmpPosLbl.Visible = True
                DobLbl.Visible = True
                EmpPhonelbl.Visible = True
                EmpEducaLbl.Visible = True
                EmpGenderlbl.Visible = True

            Next

            Connect.Close()

        End If

    End Sub

    Private Sub BtnHome_Click(sender As Object, e As EventArgs) Handles BtnHome.Click

        Me.Hide()
        Dim Employee_M = New Employee_Management
        Employee_Management.Show()

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

        Me.Hide()
        Dim Employee_M = New Employee_Management
        Employee_Management.Show()

    End Sub
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

        Me.Hide()
        Dim Employee_M = New Employee_Management
        Employee_Management.Show()

    End Sub

    Private Sub Details_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub BtnFetchData_Click(sender As Object, e As EventArgs) Handles BtnFetchData.Click

        FetchData()

    End Sub

    Private Sub BtnPrint_Click(sender As Object, e As EventArgs)

    End Sub
End Class